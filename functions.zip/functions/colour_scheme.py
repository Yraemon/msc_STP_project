
# Organise coloring of plots

import numpy as np

###########################################################################################
def hex_to_RGB(hex_str):
    """ #FFFFFF -> [255,255,255]"""
    #Pass 16 to the integer function for change of base
    return [int(hex_str[i:i+2], 16) for i in range(1,6,2)]

def get_color_gradient(c1, c2, n):
    """
    Given two hex colors, returns a color gradient
    with n colors.
    """
    assert n > 1
    c1_rgb = np.array(hex_to_RGB(c1))/255
    c2_rgb = np.array(hex_to_RGB(c2))/255
    mix_pcts = [x/(n-1) for x in range(n)]
    rgb_colors = [((1-mix)*c1_rgb + (mix*c2_rgb)) for mix in mix_pcts]
    return ["#" + "".join([format(int(round(val*255)), "02x") for val in item]) for item in rgb_colors]


###########################################################################################
# generate gradients of colours based on neurones in each population
def neurone_color_coding(n_neurones):

    # Pyr - red
    color1 = "#370059"
    color2 = "#E7B7C9"
    if n_neurones[0] == 1:
        pyr_colors = [color1]
    else:
        pyr_colors = get_color_gradient(color1, color2, n_neurones[0])
    # PV - blue
    color1 = "#002C59"
    color2 = "#B7CFE7"
    if n_neurones[1] == 1:
        pv_colors = [color1]
    else:
        pv_colors = get_color_gradient(color1, color2, n_neurones[1])
    # SOM - green
    color1 = "#275946"
    color2 = "#92A87D"
    if n_neurones[2] == 1:
        som_colors = [color1]
    else:
        som_colors = get_color_gradient(color1, color2, n_neurones[2])

    neurone_colors = pyr_colors + pv_colors + som_colors

    return neurone_colors

# print(neurone_color_coding([1,1,1]))

###########################################################################################
def synapse_color_coding(n_neurones):
    # this only generates colors for pyr<->pv and pyr<->som

    n_pyr = n_neurones[0]
    n_pv = n_neurones[1]
    n_som = n_neurones[2]

    N = np.sum(n_neurones)
    
    # other synapses
    color_matrix = np.full((N,N),'xxxxxxx')

    # PV -> Pyr -blue
    # color1 = "#274659"; color2 = "#B7BDE7"
    color1 = "#002C59"; color2 = "#B7CFE7"
    if n_pyr == 1 and n_pv == 1: 
        color_matrix[:n_pyr, n_pyr:n_pyr+n_pv] = np.array('#a5adc1')
    else:
        color_matrix[:n_pyr, n_pyr:n_pyr+n_pv] = np.array(get_color_gradient(color1, color2, n_pyr*n_pv)).reshape((n_pyr,n_pv))

    # Pyr -> PV -red
    color1 = "#592739"; color2 = "#E7B7E1"
    if n_pyr == 1 and n_pv == 1: 
        color_matrix[n_pyr:n_pyr+n_pv, :n_pyr] = np.array('#b22e01')
    else:
        color_matrix[n_pyr:n_pyr+n_pv, :n_pyr] = np.array(get_color_gradient(color1, color2, n_pyr*n_pv)).reshape((n_pv,n_pyr))

    # SOM -> Pyr -green
    color1 = "#275946"; color2 = "#B7E7BD"
    if n_pyr == 1 and n_som == 1: 
        color_matrix[:n_pyr, n_pyr+n_pv:] = np.array('#336f6b')
    else:
        color_matrix[:n_pyr, n_pyr+n_pv:] = np.array(get_color_gradient(color1, color2, n_pyr*n_som)).reshape((n_pyr,n_som))

    # Pyr -> SOM -orange
    color1 = "#594027"; color2 = "#E7E1B7"
    if n_pyr == 1 and n_som == 1: 
        color_matrix[n_pyr+n_pv:, :n_pyr] = np.array('#432e26')
    else:
        color_matrix[n_pyr+n_pv:, :n_pyr] = np.array(get_color_gradient(color1, color2, n_pyr*n_som)).reshape((n_som,n_pyr))

    return color_matrix

# print(synapse_color_coding([1,1,1]))
