
# Generate name lists of neurones/populations

import numpy as np 

###########################################################################################
# generate individual neurone names
def neurone_names(n_neurones = [1,1,1]):
    '''n_neurones = [n_pc, n_pv, n_som]'''
    
    n_pc = n_neurones[0]
    n_pv = n_neurones[1]
    n_som = n_neurones[2]

    names_list = []
    for i in range(n_pc):
        names_list.append(f'PC{i+1}')
    for i in range(n_pv):
        names_list.append(f'PV{i+1}')
    for i in range(n_som):
        names_list.append(f'SOM{i+1}')
    
    return names_list
# print(neurone_names())


###########################################################################################

# Generate synapse names and positions of changes
def synapse_names_positions(eta_matrix, n_neurones):
    # Get the indice and synapse names where eta is not 0

    eta_signs = np.sign(eta_matrix)
    names = neurone_names(n_neurones)

    position_index = []
    synapse_names = []
    for row in range(len(eta_matrix)):
        for col in range(len(eta_matrix)):
            if eta_signs[row,col] != 0:
                synapse = f'w_{names[row]}<-{names[col]}'
                synapse_names.append(synapse)
                position_index.append([row,col])
    
    return synapse_names, position_index









