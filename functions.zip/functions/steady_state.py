
# Apply threshold to rate-based model

# threshold is expressed as basal activity levels
# i.e., activity levels with no plasticity, no perturbation

import numpy as np
from scipy import optimize 
# import activation function
import functions.act_func as actFunc
# import act_func as actFunc



def r_basal(S_init, W_init):

    '''
    Args:
    S_init (N*1): external input to each neurone at t0 (S[:,0])
    W (N*N): initial weight of each synaptic connection

    Returns:
    x_b (1*N): basal activity levels of each neurone
    '''

    # number of neurones simulated
    N = len(W_init)

    S_init = np.full((1,N), 1.75)[0]

    # set up ODE equations
    # def drdt(r_steady):
    #         #r_steady = np.array([r_E, r_I1, r_I2])
    #     # I_rec = np.array(np.matrix(W_init) * np.matrix(r_steady).T).T[0]
    #     I_rec = np.dot(W_init, r_steady.T).T[0]
    #     return -r_steady + actFunc.ReLU(I_rec + S_init)
    
    
    # Find steady states: 
        # solve ODE systems by testing 10 root guesses
        # assuming that steady-state activities fall within 0 to 10
    r_steady_guess = np.random.randint(0, 10, size=(10, N))
            ## what if have multiple steady state?

    roots = []

    for guess in r_steady_guess:
        root = optimize.root(drdt, np.reshape(guess,(N,1)), method='hybr')
        positive_rate_filter = all(k > 0 for k in root.x)
            # Filter out negative rate
        steady_sol = np.around(root.x, decimals = 4)
            # around steady states up to 4 decimal places to exclude potential repeats
        
        # Filter out negative rate, fake roots, and potential repeats
        if positive_rate_filter == True and root.success == True and steady_sol.tolist() not in roots:
            roots.append(steady_sol.tolist())
    
    # print steady states found 
    # print(np.reshape(roots[0],(N,1)))
  
    # assuming only 1 steady state (return the first steady state found)
    return np.reshape(roots[0],(N,1))






################################## Test run ##################################
# N = 3
# S = 1 + 0.1*(np.ones((N,100))) # assume that there's a basal external input of 1
# pert_size = 0.5
# # S = S + pert_size
# S_init = np.array([1.75, 1.75, 1.75])

# # weight
# # outout from excitatory neurone (e)
# w_ee = 0.3
# w_i1e = 0.6
# w_i2e = 0.3
# # output from inhibitory neurone 1 (i1)
# w_ei1 = -0.6
# w_i1i1 = -0.6
# w_i2i1 = -0.3
# # output from inhibitory neurone 1 (i2)
# w_ei2 = -0.6
# w_i1i2 = 0
# w_i2i2 = 0

# W = np.array([[w_ee, w_ei1, w_ei2],
#             [w_i1e, w_i1i1, w_i1i2],
#             [w_i2e, w_i2i1, w_i2i2]]);



# print(r_basal(S_init, W))
