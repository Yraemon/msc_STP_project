
# get average activities and weights

import numpy as np

###########################################################################################
def avg_weight(weight_mat, n_neurones):

    pc = n_neurones[0]
    pv = n_neurones[0] + n_neurones[1]

    avg_pyr_pyr = np.average(weight_mat[:pc, :pc])
    avg_pyr_pv = np.average(weight_mat[:pc, pc:pv])
    avg_pyr_som = np.average(weight_mat[:pc, pv:])

    avg_pv_pyr = np.average(weight_mat[pc:pv, :pc])
    avg_pv_pv = np.average(weight_mat[pc:pv, pc:pv])
    avg_pv_som = np.average(weight_mat[pc:pv, pv:])

    avg_som_pyr = np.average(weight_mat[pv:, :pc])
    avg_som_pv = np.average(weight_mat[pv:, pc:pv])
    avg_som_som = np.average(weight_mat[pv:, pv:])

    avg_weight = np.array([avg_pyr_pyr, avg_pyr_pv, avg_pyr_som,
                           avg_pv_pyr, avg_pv_pv, avg_pv_som,
                           avg_som_pyr, avg_som_pv, avg_som_som]).reshape(3,3)
    return avg_weight

###########################################################################################

def MF_weight(weight_mat, n_neurones):

    pc = n_neurones[0]
    pv = n_neurones[0] + n_neurones[1]

    #PC->PC
    sum_col_pyr_pyr = [np.sum(weight_mat[i][:pc]) for i in range(pc)]
    avg_pyr_pyr = np.average(sum_col_pyr_pyr)
    #PV->PC
    sum_col_pyr_pv = [np.sum(weight_mat[i][pc:pv]) for i in range(pc)]
    avg_pyr_pv = np.average(sum_col_pyr_pv)
    #SOM->PC
    sum_col_pyr_som = [np.sum(weight_mat[i][pv:]) for i in range(pc)]
    avg_pyr_som = np.average(sum_col_pyr_som)

    #PC->PV
    sum_col_pv_pyr = [np.sum(weight_mat[i][:pc]) for i in range(pc,pv)]
    avg_pv_pyr = np.average(sum_col_pv_pyr)
    #PV->PV
    sum_col_pv_pv = [np.sum(weight_mat[i][pc:pv]) for i in range(pc,pv)]
    avg_pv_pv = np.average(sum_col_pv_pv)
    #SOM->PV
    sum_col_pv_som = [np.sum(weight_mat[i][pv:]) for i in range(pc,pv)]
    avg_pv_som = np.average(sum_col_pv_som)

    #PC->SOM
    sum_col_som_pyr = [np.sum(weight_mat[i][:pc]) for i in range(pv,len(weight_mat))]
    avg_som_pyr = np.average(sum_col_som_pyr)
    #PV->SOM
    sum_col_som_pv = [np.sum(weight_mat[i][pc:pv]) for i in range(pv,len(weight_mat))]
    avg_som_pv = np.average(sum_col_som_pv)
    #SOM->SOM
    sum_col_som_som = [np.sum(weight_mat[i][pv:]) for i in range(pv,len(weight_mat))]
    avg_som_som = np.average(sum_col_som_som)

    avg_weight = np.array([avg_pyr_pyr, avg_pyr_pv, avg_pyr_som,
                           avg_pv_pyr, avg_pv_pv, avg_pv_som,
                           avg_som_pyr, avg_som_pv, avg_som_som]).reshape(3,3)
    return avg_weight

###########################################################################################
def avg_activity(r, n_neurones):

    pc = n_neurones[0]
    pv = n_neurones[0] + n_neurones[1]

    avg_pyr = np.mean(r[:pc,:], axis=0)
    avg_pv = np.mean(r[pc:pv,:], axis=0)
    avg_som = np.mean(r[pv:,:], axis=0)

    average_activity = np.array([avg_pyr, avg_pv, avg_som])

    return average_activity





