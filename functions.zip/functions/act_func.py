
# Activation function

# use ReLU as activation function
def ReLU(x): 
    return x*(x>0)

# sigmoid is not suitable here























