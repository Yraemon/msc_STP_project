
# Generating matrices/vectors of model parameters

import numpy as np 

###########################################################################################
# time constant (tau)
# tau vector generator
# need adaptation if want to change tau of each population
def tau_generator(n_neurones = [1,1,1], tau = 20):
    '''n_neurones = [n_pyr, n_pv, n_som]'''
    
    N = np.sum(n_neurones)
    tau_vector = np.full((1,N), tau)

    return tau_vector[0]
# print(tau_generator())

###########################################################################################

# time constant for synaptic connections
# tau_x generator
# need adaptation if want to change tau_x of each population
def tau_x_generator(n_neurones = [1,1,1], tau_x = 40):
    '''n_neurones = [n_pyr, n_pv, n_som]'''
    
    N = np.sum(n_neurones)
    tau_vector = np.full((N,N), tau_x)

    return tau_vector
# print(tau_x_generator())

###########################################################################################

# # Meanfield weight matrix generator
# def mean_field_weight(n_neurones = [1,1,1], weight = 0.5, self_act = False, inh_inh = False):
#     '''n_neurones = [n_pyr, n_pv, n_som]'''
    
#     n_pyr = n_neurones[0]
#     n_pv = n_neurones[1]
#     n_som = n_neurones[2]
#     # compute total number of neurone populations
#     N = np.sum(n_neurones)

#     # initialise the matrix with specified weight
#     weight_matrix = np.full((N,N), weight)

#     # generate sign matrix
#     sign_matrix = np.ones((N,N))
#     sign_matrix[:, n_pyr:] = -1 # after PC columns, all columns apply inhibition

#     weight_matrix = weight_matrix*sign_matrix

#     # switch on/off self-activation
#     if self_act == False:
#         # weight_matrix[:n_pyr, :n_pyr]=0 # PC-PC
#         # weight_matrix[n_pyr:n_pyr+n_pv, n_pyr:n_pyr+n_pv]=0 # PV-PV
#         weight_matrix[N-n_som:, N-n_som:]=0 # SOM-SOM

#     # switch on/off interactions between PV and SOM
#     if inh_inh == False:
#         weight_matrix[N-n_som:, n_pyr:n_pyr+n_pv] = 0 # PV->SOM
#         # weight_matrix[n_pyr:n_pyr+n_pv, N-n_som:] = 0 # SOM->PV

#     return weight_matrix

###########################################################################################

# Meanfield weight matrix generator
def mean_field_weight(n_neurones, core_mat):
    '''n_neurones = [n_pyr, n_pv, n_som]'''

    n_pyr = n_neurones[0]
    n_pv = n_neurones[1]
    n_som = n_neurones[2]
    # compute total number of neurone populations
    N = np.sum(n_neurones)

    # initialise the matrix with specified weight
    weight_matrix = core_mat

    # generate sign matrix
    sign_matrix = np.ones((N,N))
    sign_matrix[:, n_pyr:] = -1 # after PC columns, all columns apply inhibition

    weight_matrix = weight_matrix*sign_matrix

    return weight_matrix



# Extended weight matrix generator
def weight_mat_extended(n_neurones = [1,1,1], mean_field_weight = [[0.5,-0.5,-0.5],[0.5,-0.5,-0.5],[0.5,-0.5,-0.5]]):
    '''n_neurones = [n_pyr, n_pv, n_som]
       mean_field_weight = weight_mat_generator(n_neurones, weight)'''
    
    matrix = []
    for i in range(3):
        row = []
        for j in range(3):
            mat = np.random.rand(n_neurones[i], n_neurones[j])
            # normalise the matrix to have an average of the specified mean_field_weight
            # normalised_matrix = mat - np.mean(mat) + mean_field_weight[i][j]
            normalised_matrix = mat / np.sum(mat) * mean_field_weight[i][j]*n_neurones[i]
            row.append(normalised_matrix)
        
        matrix.append(np.hstack(row))

    return np.vstack(matrix)

# print(weight_mat_extended(n_neurones = [30,30,20], mean_field_weight = mean_field_weight([1,1,1],0.5))



###########################################################################################
# matrix of learning rate generator
# assuming PC-PV=STD; PC-SOM=STF
def eta_mat_generator(n_neurones = [1,1,1], eta = 0.00015, self_act = False, inh_inh = False):
    '''n_neurones = [n_pyr, n_pv, n_som]'''

    n_pyr = n_neurones[0]
    n_pv = n_neurones[1]
    n_som = n_neurones[2]
    
    # compute total number of neurone populations
    N = np.sum(n_neurones)

    # initialise the matrix with specified eta
    eta_matrix = np.full((N,N), eta)

    # generate sign matrix
    sign_matrix = np.ones((N,N))
    sign_matrix[n_pyr:n_pyr+n_pv, :n_pyr] = -1 # set STD for PC->PV
    sign_matrix[:n_pyr, N-n_som:] = -1 # set STF for SOM->PC


    eta_matrix = eta_matrix*sign_matrix

    # switch on/off self-activation
    if self_act == False:
        eta_matrix[:n_pyr, :n_pyr]=0 # PC-PC
        eta_matrix[n_pyr:n_pyr+n_pv, n_pyr:n_pyr+n_pv]=0 # PV-PV
        eta_matrix[N-n_som:, N-n_som:]=0 # SOM-SOM

    # switch on/off interactions between PV and SOM
    if inh_inh == False:
        eta_matrix[N-n_som:, n_pyr:n_pyr+n_pv] = 0 # PV->SOM
        eta_matrix[n_pyr:n_pyr+n_pv, N-n_som:] = 0 # SOM->PV


    # switch off SOM->Pyr
    eta_matrix[:n_pyr, N-n_som:] = 0
    # eta_matrix[:n_pyr, N-n_som:] = 0.000015

    # switch off PV->Pyr
    # eta_matrix[n_pyr:n_pyr+n_pv, :n_pyr] = 0

    # switch off Pyr->PV
    # eta_matrix[:n_pyr, n_pyr:n_pyr+n_pv] = 0

    # switch off Pyr->SOM
    # eta_matrix[N-n_som:, :n_pyr] = 0




    return eta_matrix
# eta_mat_generator()

###########################################################################################





















