# design perturbation protocol

import numpy as np

###########################################################################################

def protocol(n_neurones, pert_fraction, T_dur, interval, N_rep, pert_size, dt=0.1):
    ''' 
    Args:
        n_neurones = [2,1,1]
        pert_fraction = [0.5, 1, 1] (i.e., perturbation applied to 50% of Pyr cells and all the PV and SOM cells)
        pert_size = [1,1,1]
    
    Returns:
        T: an array of time points from start to end
        S: perturbation protocol
    '''

    N = np.sum(n_neurones);  # number of nodes

    # number of neurones in each population
    n_pyr = int(n_neurones[0])
    n_pv = int(n_neurones[1])
    n_som = int(n_neurones[2])

    # number of neurones perturbed in each population
    neurone_pert = np.around(np.array(n_neurones) * np.array(pert_fraction), 0)
    pert_pyr = int(neurone_pert[0])
    pert_pv = int(neurone_pert[1])
    pert_som = int(neurone_pert[2])


    # temporal profiles
    t_start = 0   # perturbation start time
    T_dur = T_dur # perturbation duration
    interval = interval # interval between perturbation
    N_rep = N_rep # number of perturbations applied

    dt = dt  # time step
    t_end = t_start + (T_dur+interval)*N_rep + 500
    T = np.arange(0, t_end, dt)

    # index for perturbation periods
    t_index = []
    for i in range(1,N_rep+1):
        t1 = t_start + (T_dur+interval)*(i-1)
        t2 = t1 + T_dur
        index = np.concatenate(np.where(np.logical_and(T<=t2, T>=t1)))
        t_index.append(index)
    t_index = np.concatenate(t_index)


    # Initialise external input
    S_pre = 2 + 1.5*(np.random.rand(N,len(T))) # basal external input of 1 plus some variation
    S=np.zeros((N,len(T)))
    S[:,:]=S_pre[:,:]
    # print(S[:,t_index])
    # perturbation to pyr cells
    S[:pert_pyr, t_index] = S[:pert_pyr, t_index] + pert_size[0]
    # print(S)
    # perturbation to pv cells
    # S[n_pyr:n_pyr+pert_pv, t_index] = S[n_pyr:n_pyr+pert_pv, t_index] + pert_size[1]
    # perturbation to som cells
    # S[n_pyr+n_pv:n_pyr+n_pv+pert_som, t_index] = S[n_pyr+n_pv:n_pyr+n_pv+pert_som, t_index] + pert_size[2]
    # print(S[:,t_index])

    return T, S_pre, S





################################## Test run ##################################

# n_neurones = [3,1,2]
# pert_fraction = [0.5,1,1]
# dt = 0.1
# T_dur = 5
# interval = 10
# N_rep = 10
# pert_size = [1,1,1]

# time, s_test = protocol(n_neurones, pert_fraction, T_dur, interval, N_rep, pert_size, dt=0.1)
# print(s_test)

























